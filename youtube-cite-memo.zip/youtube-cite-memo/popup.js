const firebaseConfig = {
  apiKey: "AIzaSyBpoEOgyGHiSt5w07sh_KkSg852Bw34Qxc",
  authDomain: "ood-blog.firebaseapp.com",
  projectId: "ood-blog",
  storageBucket: "ood-blog.appspot.com",
  messagingSenderId: "732775523621",
  appId: "1:732775523621:web:b134125ad811e63aef66cc",
  measurementId: "G-V2MZY72Y23"
};

const app = firebase.initializeApp(firebaseConfig);
const db = app.firestore();
const storage = app.storage();

const textarea = document.getElementById("cite");
const save = document.getElementById("save");
let url ="123";

save.addEventListener("click",()=>{
  chrome.tabs.query({active: true, lastFocusedWindow: true}, tabs => {
      url = tabs[0].url;
      text = textarea.value;
      db.collection("youtube").add({video : url, text : text}).then((docRef) => {
        save.innerHTML="saved!";
        setTimeout(()=>{save.innerHTML="save";},2000);
      });
  });
});
